package edu.uci.ics.fabflixmobile;

import android.content.Intent;
import android.os.Bundle;
import android.support.v7.app.ActionBarActivity;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;

import com.android.volley.Request;
import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.StringRequest;

import java.util.HashMap;
import java.util.Map;

public class LoginActivity extends ActionBarActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_red);

        final EditText username = (EditText) findViewById(R.id.username);
        final EditText password = (EditText) findViewById(R.id.password);
        final Button bLogin = (Button) findViewById(R.id.buttonsub);

        bLogin.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                final String email = username.getText().toString();
                final String pass = password.getText().toString();
                //Log.d("Message: ", "HELLO! ");
                connectToTomcat(view, email, pass);
            }
        });
    }

    public void connectToTomcat(final View view, String username, String password) {

            final Map<String, String> params = new HashMap<String, String>();
            params.put("username", username);
            params.put("password", password);

        // Use the same network queue across our application
        final RequestQueue queue = NetworkManager.sharedManager(this).queue;

        // 10.0.2.2 is the host machine when running the android emulator
        final StringRequest afterLoginRequest = new StringRequest(Request.Method.POST, "http://3.18.102.16:8080/fabflix/api/android-login",
                new Response.Listener<String>() {
                    @Override
                    public void onResponse(String response) {

                        Log.d("username.reponse", response);
                        if(response.contains("fail")){

                            ((TextView) findViewById(R.id.http)).setText(response);
                        }else{
                            String success_message = "Login Successfully!";
                            goToSearch(view, success_message);
                        }

                    }
                },
                new Response.ErrorListener() {
                    @Override
                    public void onErrorResponse(VolleyError error) {
                        // error
                        Log.d("security.error", error.toString());
                    }
                }
        ) {
            @Override
            protected Map<String, String> getParams() {
                return params;
            }
        };
        queue.add(afterLoginRequest);
    }


    public void goToSearch(View view, String message) {

        Intent goToIntent = new Intent(this, SearchActivity.class);

        goToIntent.putExtra("message", message);

        startActivity(goToIntent);
    }
}
