package edu.uci.ics.fabflixmobile;

import android.content.Intent;
import android.os.Bundle;
import android.support.v7.app.ActionBarActivity;
import android.util.Log;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ListView;
import android.widget.TextView;
import android.widget.Toast;
import android.widget.AdapterView;
import android.widget.BaseAdapter;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;
import com.android.volley.Request;
import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.StringRequest;

import java.util.HashMap;
import java.util.Map;


public class MovieListActivity extends ActionBarActivity {
    private JSONArray jsonResponse = null;
    private int currPage = 1;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_green);

        Bundle bundle = getIntent().getExtras();
        String query = bundle.get("query").toString();

        populateListView(query);
    }
    public void populateListView(String query){
        final Map<String, String> params = new HashMap<String, String>();
        params.put("query", query);

        // Use the same network queue across our application
        final RequestQueue queue = NetworkManager.sharedManager(this).queue;

        final StringRequest movieRequest = new StringRequest(Request.Method.POST, "http://3.18.102.16:8080/fabflix/api/android-view",
                new Response.Listener<String>() {
                    @Override
                    public void onResponse(String response) {
                        Log.d("Response", response);
                        try {
                            jsonResponse = new JSONArray(response);
                            String success = jsonResponse.getJSONObject(0).getString("status");
                            Log.d("stature", success);
                            if (success.equalsIgnoreCase("success")) {

                                final ListView listView = (ListView) findViewById(R.id.listItems);
                                final Button bNext = (Button) findViewById(R.id.next);
                                final Button bPrev = (Button) findViewById(R.id.prev);

                            }else{
                                Log.d("status", success);
                                Intent goToIntent = new Intent(MovieListActivity.this, SearchActivity.class);
                                goToIntent.putExtra("message", "Could not find result");
                                startActivity(goToIntent);
                            }

                        } catch (JSONException e) {
                            e.printStackTrace();
                        }
                    }
                },

                new Response.ErrorListener() {
                    @Override
                    public void onErrorResponse(VolleyError volleyError) {
                        // error
                        Log.d("security.error", volleyError.toString());
                    }
                }
        ){
            @Override
            protected Map<String, String> getParams() {
                return params;
            }
        };

        queue.add(movieRequest);
    }}