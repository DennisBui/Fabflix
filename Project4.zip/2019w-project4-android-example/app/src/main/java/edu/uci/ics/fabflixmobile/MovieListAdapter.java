package edu.uci.ics.fabflixmobile;

import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.ArrayAdapter;
import android.widget.TextView;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

public class MovieListAdapter extends BaseAdapter {

    JSONArray arrayList;

    public MovieListAdapter(JSONArray arrayList) {
        this.arrayList = arrayList;
    }

    @Override
    public int getCount() {
        return arrayList.length();
    }

    @Override
    public Object getItem(int i) {
        return null;
    }

    @Override
    public long getItemId(int i) {
        return 0;
    }

    @Override
    public View getView(int i, View view, ViewGroup viewGroup) {

        TextView titleView = (TextView) view.findViewById(R.id.title);
        TextView yearView = (TextView) view.findViewById(R.id.year);
        TextView directorView = (TextView) view.findViewById(R.id.director);
        TextView genresView = (TextView) view.findViewById(R.id.movie_genres);
        TextView starsView = (TextView) view.findViewById(R.id.movie_stars);

        try {
            JSONObject jsonObject = arrayList.getJSONObject(i);
            titleView.setText(jsonObject.getString("title"));
            yearView.setText(jsonObject.getString("year"));
            directorView.setText(jsonObject.getString("director"));
            genresView.setText(jsonObject.getString("listGenres"));
            starsView.setText(jsonObject.getString("listStarsName"));

        } catch (JSONException e) {
            e.printStackTrace();
        }
        return view;
    }
}
