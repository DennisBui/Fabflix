package edu.uci.ics.fabflixmobile;

import android.content.Intent;
import android.support.v7.app.ActionBarActivity;
import android.os.Bundle;
import android.widget.TextView;
import android.widget.Toast;

import org.json.JSONException;
import org.json.JSONObject;

public class SingleMovieActivity extends ActionBarActivity {
    @Override
    protected void onCreate(Bundle savedInstanceState)
    {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_single_movie);

        Bundle bundle = getIntent().getExtras();

        TextView titleView = (TextView) findViewById(R.id.movie_title);
        TextView yearView = (TextView) findViewById(R.id.movie_year);
        TextView directorView = (TextView) findViewById(R.id.movie_director);
        TextView genresView = (TextView) findViewById(R.id.movie_genres);
        TextView starsView = (TextView) findViewById(R.id.movie_stars);

        titleView.setText("Title: "+ bundle.getString("title"));
        yearView.setText("Year: " + bundle.getString("year"));
        directorView.setText("Director: " + bundle.getString("director"));
        genresView.setText("Genres: " + bundle.getString("genres"));
        starsView.setText("Stars: " + bundle.getString("stars"));
    }
}
